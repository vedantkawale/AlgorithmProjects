# Project-4
Iceberg avoiding problem

Group members:

Ada Lovelace adalovelace@csu.fullerton.edu

Charles Babbage charlesbab@csu.fullerton.edu
